/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package factorial2;

import java.util.Scanner;

/**
 *
 * @author peete
 */
public class Factorial2 {
    
/**
     * @param args the command line arguments
     */
public static void main(String[] args) {
        int counter;
        Scanner input = new Scanner(System.in);    
        System.out.println("Dwse mou tov ari8mo tou opoiou 8es to paragovtiko: ");
        counter = input.nextInt();
        int fact = factorial(counter);
        System.out.println("To paragovtiko tou "+counter+" is: "+fact);
    }

    static int factorial(int counter)
    {
        if(counter == 1)
            return 1;
        return counter * (factorial(counter-1));
    }       
    
}
