/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package factorial;

import java.util.Scanner;

/**
 *
 * @author peete
 */
public class Factorial {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int i;  
        int factorial=1;  
        int counter;//It is the number to calculate factorial    
        Scanner input = new Scanner(System.in);    
        System.out.println("Dwse mou tov ari8mo tou opoiou 8es to paragovtiko: ");
        counter = input.nextInt();
        
        for(i=1;i<=counter;i++){    
            factorial=factorial*i;    
        }    
        System.out.println("To paragovtiko tou "+counter+" is: "+factorial);    
    }  
}