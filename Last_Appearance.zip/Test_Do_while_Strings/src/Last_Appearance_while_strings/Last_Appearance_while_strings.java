/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Last_Appearance_while_strings;

/**
 *
 * @author peete
 */
public class Last_Appearance_while_strings {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
       
        String word1 = "10hel10lo10";
        int x=word1.length();
        
        while(x>=0 && word1.charAt(x-1)!='l'){
            x--;
        }
        if (x==0)
            System.out.println("Dev yparxei to "+'l'+" stnv symboloseira");
        else 
            System.out.println("H teleutaia 8esn tou "+'l'+" stnv symboloseira eivai n "+(x-1)+"n");
            
            }
        }
        
    
