/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fibonacci;

import java.util.Scanner;
import static jdk.nashorn.tools.ShellFunctions.input;

/**
 *
 * @author peete
 */
public class Fibonacci {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int n1=0;
        int n2=1;
        int n3,i;
        int count;
        Scanner input = new Scanner(System.in);    
        System.out.println("Dwse mou posous ari8mous Fibonacci 8es: ");
        count = input.nextInt();
        System.out.println("---------------------");
        System.out.println(n1+"\r\n"+n2);//printing 0 and 1    
    
        for(i=2;i<count;++i)//loop starts from 2 because 0 and 1 are already printed    
            {    
             n3=n1+n2;    
             System.out.println(n3);    
             n1=n2;    
             n2=n3;    
            }    

    }
}